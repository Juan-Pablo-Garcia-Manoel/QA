package br.edu.calc.plus.CalculatorPlus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculatorPlusApplicationTests {

	@Test
	void contextLoads() {
	}

}
